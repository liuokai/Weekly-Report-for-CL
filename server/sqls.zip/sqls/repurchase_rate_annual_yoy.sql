-- 年度项目回头率统计

WITH yearly_metrics AS (
    -- 第一步：按年维度汇总数据
    SELECT YEAR(off_clock_time)                                      AS s_year,
           COUNT(DISTINCT order_uid)                                 AS total_orders,
           SUM(IF(is_massager_project_return_customer = '是', 1, 0)) AS repurchase_orders
    FROM dwd_sales_order_detail
    WHERE off_clock_time IS NOT NULL
      AND off_clock_time >= '2024-01-01'
      and service_duration >= 40
    GROUP BY 1
),
rate_calculation AS (
    -- 第二步：计算回头率
    SELECT
        *,
        ROUND(repurchase_orders / NULLIF(total_orders, 0) * 100, 2) AS repurchase_rate
    FROM yearly_metrics
)
-- 第三步：自连接计算同比
SELECT
    curr.s_year,
    curr.total_orders,
    curr.repurchase_orders,
    curr.repurchase_rate,
    prev.repurchase_rate                                     AS prev_year_rate,
    -- 计算同比增减百分点
    ROUND(curr.repurchase_rate - prev.repurchase_rate, 2)    AS yoy_change_pct
FROM rate_calculation curr
LEFT JOIN rate_calculation prev ON curr.s_year = prev.s_year + 1
ORDER BY curr.s_year DESC;